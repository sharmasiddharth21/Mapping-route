const express = require("express");
const path = require("path");
const { spawn } = require("child_process");

const app = express();
const PORT = 3000;
const projectRoot = path.join(__dirname, "..");
const enginePath = path.join(projectRoot, "engine", "smartroute.exe");

app.use(express.json());
app.use(express.static(path.join(projectRoot, "frontend")));

const locations = {
  "Kashmere Gate": 0,
  "Civil Lines": 1,
  "Connaught Place": 2,
  "ITO": 3,
  "India Gate": 4,
  "AIIMS": 5,
  "Hauz Khas": 6,
  "Saket": 7
};

app.get("/api/locations", (req, res) => {
  res.json(Object.keys(locations));
});

app.post("/api/route", (req, res) => {
  const { source, destination, mode } = req.body || {};

  if (!(source in locations) || !(destination in locations)) {
    return res.status(400).json({ error: "Please select valid locations." });
  }

  if (!["ROAD", "METRO"].includes(mode)) {
    return res.status(400).json({ error: "Please select Road or Metro mode." });
  }

  if (source === destination) {
    return res.status(400).json({ error: "Source and destination must be different." });
  }

  const child = spawn(enginePath, [
    mode,
    String(locations[source]),
    String(locations[destination])
  ], { windowsHide: true });

  let output = "";
  let errorOutput = "";

  child.stdout.on("data", chunk => output += chunk.toString());
  child.stderr.on("data", chunk => errorOutput += chunk.toString());

  child.on("error", () => {
    res.status(500).json({
      error: "Could not start the C engine. Compile the C files first."
    });
  });

  child.on("close", code => {
    try {
      const result = JSON.parse(output);
      if (code !== 0 || result.error) {
        return res.status(400).json(result);
      }
      res.json(result);
    } catch {
      res.status(500).json({
        error: "The C engine returned an invalid response.",
        details: errorOutput
      });
    }
  });
});

app.listen(PORT, () => {
  console.log(`Delhi SmartRoute is running at http://localhost:${PORT}`);
});
