const locations = [
  "Kashmere Gate",
  "Civil Lines",
  "Connaught Place",
  "ITO",
  "India Gate",
  "AIIMS",
  "Hauz Khas",
  "Saket"
];

const sourceSelect = document.getElementById("source");
const destinationSelect = document.getElementById("destination");
const message = document.getElementById("message");
const resultBox = document.getElementById("result");
const findButton = document.getElementById("findRoute");

let selectedMode = "ROAD";
let routeLayer = null;

function fillSelect(select, selectedValue) {
  locations.forEach(name => {
    const option = document.createElement("option");
    option.value = name;
    option.textContent = name;
    if (name === selectedValue) option.selected = true;
    select.appendChild(option);
  });
}

fillSelect(sourceSelect, "Kashmere Gate");
fillSelect(destinationSelect, "Connaught Place");

document.querySelectorAll(".mode").forEach(button => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".mode").forEach(b => b.classList.remove("active"));
    button.classList.add("active");
    selectedMode = button.dataset.mode;
  });
});

// The map is only a display. The C program calculates the route.
const map = L.map("map").setView([28.625, 77.222], 12);

L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
  maxZoom: 19,
  attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
}).addTo(map);

async function findRoute() {
  const source = sourceSelect.value;
  const destination = destinationSelect.value;

  if (source === destination) {
    message.textContent = "Choose two different locations.";
    resultBox.classList.add("hidden");
    return;
  }

  findButton.disabled = true;
  message.textContent = "Calculating shortest route using Dijkstra...";
  resultBox.classList.add("hidden");

  try {
    const response = await fetch("/api/route", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ source, destination, mode: selectedMode })
    });

    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Route calculation failed.");

    document.getElementById("distance").textContent =
      `${data.distance.toFixed(2)} km`;

    const steps = document.getElementById("routeSteps");
    steps.replaceChildren();

    data.path.forEach(place => {
      const item = document.createElement("li");
      item.textContent = place.name;
      steps.appendChild(item);
    });

    if (routeLayer) map.removeLayer(routeLayer);

    const coordinates = data.path.map(p => [p.lat, p.lng]);
    routeLayer = L.polyline(coordinates, {
      color: selectedMode === "ROAD" ? "#2563eb" : "#16a34a",
      weight: 6
    }).addTo(map);

    data.path.forEach((place, index) => {
      L.marker([place.lat, place.lng])
        .addTo(map)
        .bindPopup(`${index + 1}. ${place.name}`);
    });

    map.fitBounds(routeLayer.getBounds(), { padding: [40, 40] });
    message.textContent = `${selectedMode === "ROAD" ? "Road" : "Metro"} route found successfully.`;
    resultBox.classList.remove("hidden");
  } catch (error) {
    message.textContent = error.message;
  } finally {
    findButton.disabled = false;
  }
}

findButton.addEventListener("click", findRoute);
