#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "graph.h"
#include "dijkstra.h"

static void add_locations(Graph *g) {
    add_node(g, 0, "Kashmere Gate", 28.6677, 77.2273);
    add_node(g, 1, "Civil Lines", 28.6769, 77.2250);
    add_node(g, 2, "Connaught Place", 28.6315, 77.2167);
    add_node(g, 3, "ITO", 28.6289, 77.2405);
    add_node(g, 4, "India Gate", 28.6129, 77.2295);
    add_node(g, 5, "AIIMS", 28.5672, 77.2100);
    add_node(g, 6, "Hauz Khas", 28.5494, 77.2001);
    add_node(g, 7, "Saket", 28.5245, 77.2066);
}

static void build_road_graph(Graph *g) {
    init_graph(g);
    add_locations(g);

    /* Sample road distances in kilometres (illustrative, not live data). */
    add_undirected_edge(g, 0, 1, 2.8);
    add_undirected_edge(g, 1, 2, 4.2);
    add_undirected_edge(g, 0, 3, 7.5);
    add_undirected_edge(g, 3, 2, 3.5);
    add_undirected_edge(g, 2, 4, 3.8);
    add_undirected_edge(g, 4, 5, 7.0);
    add_undirected_edge(g, 2, 5, 8.5);
    add_undirected_edge(g, 5, 6, 4.0);
    add_undirected_edge(g, 6, 7, 5.0);
    add_undirected_edge(g, 5, 7, 7.0);
}

static void build_metro_graph(Graph *g) {
    init_graph(g);
    add_locations(g);

    /* Simplified sample Metro links in kilometres; not official connectivity. */
    add_undirected_edge(g, 0, 2, 6.0);
    add_undirected_edge(g, 2, 5, 8.0);
    add_undirected_edge(g, 5, 6, 3.5);
    add_undirected_edge(g, 6, 7, 4.5);
    add_undirected_edge(g, 0, 1, 2.0);
    add_undirected_edge(g, 1, 4, 7.0);
    add_undirected_edge(g, 4, 5, 6.0);
    add_undirected_edge(g, 2, 3, 2.5);
    add_undirected_edge(g, 3, 4, 3.0);
}

static int find_node_index(const Graph *g, int id) {
    for (int i = 0; i < g->node_count; i++) {
        if (g->nodes[i].id == id) return i;
    }
    return -1;
}

int main(int argc, char *argv[]) {
    if (argc != 4) {
        printf("{\"error\":\"Usage: smartroute <ROAD|METRO> <source_id> <destination_id>\"}\n");
        return 1;
    }

    char mode[10];
    strncpy(mode, argv[1], sizeof(mode) - 1);
    mode[sizeof(mode) - 1] = '\0';
    for (int i = 0; mode[i]; i++) {
        if (mode[i] >= 'a' && mode[i] <= 'z') mode[i] -= ('a' - 'A');
    }

    char *end1, *end2;
    long source = strtol(argv[2], &end1, 10);
    long destination = strtol(argv[3], &end2, 10);
    if (*end1 != '\0' || *end2 != '\0' || source < 0 || destination < 0) {
        printf("{\"error\":\"Invalid location ID.\"}\n");
        return 1;
    }

    Graph graph;
    if (strcmp(mode, "ROAD") == 0) {
        build_road_graph(&graph);
    } else if (strcmp(mode, "METRO") == 0) {
        build_metro_graph(&graph);
    } else {
        printf("{\"error\":\"Mode must be ROAD or METRO.\"}\n");
        return 1;
    }

    int path[MAX_NODES];
    int path_length = 0;
    double total_distance = 0.0;

    if (!find_shortest_path(&graph, (int)source, (int)destination,
                            path, &path_length, &total_distance)) {
        printf("{\"error\":\"No route found for the selected locations.\"}\n");
        return 1;
    }

    printf("{\"mode\":\"%s\",\"distance\":%.2f,\"path\":[", mode, total_distance);

    for (int i = 0; i < path_length; i++) {
        int index = find_node_index(&graph, path[i]);
        if (i > 0) printf(",");
        printf("{\"id\":%d,\"name\":\"%s\",\"lat\":%.6f,\"lng\":%.6f}",
               graph.nodes[index].id, graph.nodes[index].name,
               graph.nodes[index].lat, graph.nodes[index].lng);
    }

    printf("]}\n");
    return 0;
}
