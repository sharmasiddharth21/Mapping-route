#ifndef GRAPH_H
#define GRAPH_H

#define MAX_NODES 10

typedef struct {
    int to;
    double weight;
    int active;
} Edge;

typedef struct {
    int id;
    char name[40];
    double lat;
    double lng;
    Edge edges[20];
    int edge_count;
} Node;

typedef struct {
    Node nodes[MAX_NODES];
    int node_count;
} Graph;

void init_graph(Graph *graph);
int add_node(Graph *graph, int id, const char *name, double lat, double lng);
void add_undirected_edge(Graph *graph, int from, int to, double weight);

#endif
