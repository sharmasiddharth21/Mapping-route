#ifndef DIJKSTRA_H
#define DIJKSTRA_H

#include "graph.h"

int find_shortest_path(
    const Graph *graph,
    int source_id,
    int destination_id,
    int path[],
    int *path_length,
    double *total_distance
);

#endif
