#include <string.h>
#include "graph.h"

void init_graph(Graph *graph) {
    graph->node_count = 0;
}

int add_node(Graph *graph, int id, const char *name, double lat, double lng) {
    if (graph->node_count >= MAX_NODES) return 0;

    Node *node = &graph->nodes[graph->node_count++];
    node->id = id;
    strncpy(node->name, name, sizeof(node->name) - 1);
    node->name[sizeof(node->name) - 1] = '\0';
    node->lat = lat;
    node->lng = lng;
    node->edge_count = 0;
    return 1;
}

void add_undirected_edge(Graph *graph, int from, int to, double weight) {
    int i, from_index = -1, to_index = -1;

    for (i = 0; i < graph->node_count; i++) {
        if (graph->nodes[i].id == from) from_index = i;
        if (graph->nodes[i].id == to) to_index = i;
    }

    if (from_index < 0 || to_index < 0) return;

    Node *a = &graph->nodes[from_index];
    Node *b = &graph->nodes[to_index];

    if (a->edge_count < 20) {
        Edge *e = &a->edges[a->edge_count++];
        e->to = to;
        e->weight = weight;
        e->active = 1;
    }

    if (b->edge_count < 20) {
        Edge *e = &b->edges[b->edge_count++];
        e->to = from;
        e->weight = weight;
        e->active = 1;
    }
}
