#include <float.h>
#include "dijkstra.h"

static int get_index(const Graph *graph, int id) {
    for (int i = 0; i < graph->node_count; i++) {
        if (graph->nodes[i].id == id) return i;
    }
    return -1;
}

int find_shortest_path(
    const Graph *graph,
    int source_id,
    int destination_id,
    int path[],
    int *path_length,
    double *total_distance
) {
    double distance[MAX_NODES];
    int visited[MAX_NODES] = {0};
    int previous[MAX_NODES];
    int source = get_index(graph, source_id);
    int destination = get_index(graph, destination_id);

    *path_length = 0;
    *total_distance = 0.0;

    if (source < 0 || destination < 0) return 0;

    for (int i = 0; i < graph->node_count; i++) {
        distance[i] = DBL_MAX;
        previous[i] = -1;
    }
    distance[source] = 0.0;

    for (int count = 0; count < graph->node_count; count++) {
        int current = -1;
        double best = DBL_MAX;

        /* Select the unvisited node with the smallest known distance. */
        for (int i = 0; i < graph->node_count; i++) {
            if (!visited[i] && distance[i] < best) {
                best = distance[i];
                current = i;
            }
        }

        if (current == -1) break;
        if (current == destination) break;

        visited[current] = 1;

        /* Relax all active edges from the current node. */
        const Node *node = &graph->nodes[current];
        for (int e = 0; e < node->edge_count; e++) {
            if (!node->edges[e].active) continue;

            int next = get_index(graph, node->edges[e].to);
            if (next < 0 || visited[next]) continue;

            double new_distance = distance[current] + node->edges[e].weight;
            if (new_distance < distance[next]) {
                distance[next] = new_distance;
                previous[next] = current;
            }
        }
    }

    if (distance[destination] == DBL_MAX) return 0;

    /* Rebuild the route backwards, then reverse it. */
    int reverse_path[MAX_NODES];
    int length = 0;
    int current = destination;

    while (current != -1 && length < MAX_NODES) {
        reverse_path[length++] = graph->nodes[current].id;
        if (current == source) break;
        current = previous[current];
    }

    if (length == 0 || reverse_path[length - 1] != source_id) return 0;

    for (int i = 0; i < length; i++) {
        path[i] = reverse_path[length - 1 - i];
    }

    *path_length = length;
    *total_distance = distance[destination];
    return 1;
}
