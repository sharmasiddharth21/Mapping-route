# Delhi SmartRoute (Beginner Version)

A small route-planning project demonstrating a weighted graph, adjacency lists,
and Dijkstra's shortest-path algorithm in C. A Node.js/Express server connects
the C program to a simple HTML/CSS/JavaScript frontend. Leaflet displays the
route on an OpenStreetMap map.

## Important data note

This project uses a tiny illustrative network and assumed distances. It does
not provide verified road geometry, official Delhi Metro connectivity, live
traffic, train schedules, or travel-time estimates. The map draws straight
segments between sample landmark coordinates; it is not turn-by-turn navigation.

## Requirements

- Windows
- GCC compiler available as `gcc` in PATH
- Node.js and npm
- Internet connection for Leaflet and OpenStreetMap map tiles

## 1. Compile the C engine

Open a terminal in the project root:

```bash
gcc engine/main.c engine/graph.c engine/dijkstra.c -o engine/smartroute.exe
```

## 2. Test the requested route directly

```bash
engine/smartroute.exe ROAD 0 2
```

Expected result includes:
- Kashmere Gate
- Civil Lines
- Connaught Place
- Distance: 7.00 km

## 3. Install backend packages

```bash
cd backend
npm install
```

## 4. Start the website

```bash
npm start
```

Open http://localhost:3000

## 5. Try the project

Default test:
- Source: Kashmere Gate
- Destination: Connaught Place
- Mode: Road

Try Metro mode and other pairs too.

## How it works

1. The browser sends source, destination and mode to `/api/route`.
2. Express validates the request.
3. Node starts the compiled C executable with numeric location IDs.
4. The C program builds the selected graph and runs Dijkstra.
5. C prints a JSON route.
6. Node returns the JSON to the browser.
7. JavaScript shows the route and draws its sample coordinates on Leaflet.

## Algorithm

This beginner implementation uses an adjacency list and the simple O(V^2)
version of Dijkstra: repeatedly choose the unvisited node with the smallest
known distance, then relax its outgoing edges. A binary heap can be added later.

## Viva points

- Vertex: a location in the network.
- Edge: a connection between two locations.
- Weight: assumed distance of a connection.
- Weighted graph: graph whose edges have weights.
- Adjacency list: each node stores its connected neighbours.
- Dijkstra: finds a shortest path when edge weights are non-negative.
- Complexity here: O(V^2 + E), using a simple scan to select the next node.
