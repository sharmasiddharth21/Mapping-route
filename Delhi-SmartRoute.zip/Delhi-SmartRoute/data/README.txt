The current beginner version stores its small sample network in engine/main.c
so it is easy to understand and run. The road and Metro distances are
illustrative assumptions, not verified real-world route data.

A later improvement can move these records into CSV files and load them
into the graph.
